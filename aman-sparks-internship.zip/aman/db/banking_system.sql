-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2020 at 05:16 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banking_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `account_number` int(11) NOT NULL,
  `account_type` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phno` bigint(20) NOT NULL,
  `address` text NOT NULL,
  `cur_balance` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`account_number`, `account_type`, `name`, `email`, `phno`, `address`, `cur_balance`) VALUES
(1, 'savings', 'Vikrant Saini', 'vikrsain@14.com', 8908908456, '#26 indra nagar,bangalore', 40000),
(2, 'savings', 'Yashraj', 'yashraj@76.com', 9988998800, '#556 navi mumbai, india.', 88800),
(3, 'savings', 'kevin keith', 'kkieth@1234.com', 7897897890, '#washington DC, America', 10500),
(4, 'current', 'chris', 'chrisjhon@1234.com', 9789978978, '#church street , Hydrabad, india', 22000),
(5, 'savings', 'Hemanth rai', 'hemanth@5634.com', 8529741631, '#667 nagpur, india', 98500),
(6, 'current', 'roshan kumar', 'roshankr@94.com', 5678123499, '#55 KR market, Bangalore', 88000),
(7, 'savings', 'Jignesh', 'jigdutta@39.com', 1235456789, '#6 gnd floor, 5th cross, Mangalore india', 90000),
(8, 'savings', 'sanjay dutt', 'duttsanjay@7890.com', 9525135785, '#south delhi,India', 55000),
(9, 'current', 'roky charles', 'charlesrock@1234.com', 9898653265, '#niger, Africa ', 66000),
(10, 'savings', 'binod sharma', 'binodshar@1234.com', 9584162849, '#11,1st floor, 5th cross,chennai', 200000);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `from_account_no` int(11) NOT NULL,
  `to_account_no` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `message` text NOT NULL,
  `amount_sent` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`account_number`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `account_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
